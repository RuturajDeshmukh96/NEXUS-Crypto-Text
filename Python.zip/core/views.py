import logging
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import TemplateView, CreateView, ListView, View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta

from .models import CryptoLog
from . import cipher

logger = logging.getLogger(__name__)

class LandingView(TemplateView):
    template_name = 'landing.html'

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('dashboard')
        return super().get(request, *args, **kwargs)

class RegisterView(View):
    template_name = 'auth/register.html'

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('dashboard')
        return render(request, self.template_name)

    def post(self, request, *args, **kwargs):
        first_name = request.POST.get('first_name', '')
        last_name = request.POST.get('last_name', '')
        email = request.POST.get('email', '')
        mobile = request.POST.get('mobile_number', '')
        password = request.POST.get('password', '')
        
        try:
            from django.contrib.auth.models import User
            from .models import UserProfile
            user = User.objects.create_user(username=email, email=email, password=password, first_name=first_name, last_name=last_name)
            UserProfile.objects.create(user=user, mobile_number=mobile)
            login(request, user)
            return redirect('dashboard')
        except Exception as e:
            logger.error(f"Registration error: {e}")
            return render(request, self.template_name, {'error': 'Registration failed. Email might already be in use.'})

class ForgotPasswordView(TemplateView):
    template_name = 'auth/forgot_password.html'

class DashboardView(LoginRequiredMixin, TemplateView):
    template_name = 'dashboard/dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        logs = CryptoLog.objects.filter(user=self.request.user)
        context['total_encryptions'] = logs.filter(operation_type='ENCRYPT').count()
        context['total_decryptions'] = logs.filter(operation_type='DECRYPT').count()
        context['recent_logs'] = logs[:5]
        return context

class EncryptView(LoginRequiredMixin, View):
    template_name = 'dashboard/encrypt.html'

    def get(self, request):
        return render(request, self.template_name)

    def post(self, request):
        raw_text = request.POST.get('raw_text', '').strip()
        encryption_key = request.POST.get('encryption_key', '').strip()
        
        context = {}
        if not raw_text:
            context['error'] = 'Plain text is required for encryption.'
            return render(request, self.template_name, context)

        if not encryption_key:
            encryption_key = cipher.generate_random_passphrase(16)
            context['generated_key'] = encryption_key

        try:
            encrypted_val = cipher.encrypt_text(raw_text, encryption_key)
            context['encrypted_text'] = encrypted_val
            
            # Save history
            CryptoLog.objects.create(
                user=request.user,
                operation_type='ENCRYPT',
                text_fragment=encrypted_val[:30] + '...',
                full_cipher=encrypted_val,
                status='SUCCESS'
            )
            messages.success(request, 'Data encrypted successfully.')
        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            context['error'] = 'Encryption process failed.'
            CryptoLog.objects.create(
                user=request.user,
                operation_type='ENCRYPT',
                text_fragment='ERROR',
                full_cipher='FAILED',
                status='FAILED'
            )

        return render(request, self.template_name, context)

class DecryptView(LoginRequiredMixin, View):
    template_name = 'dashboard/decrypt.html'

    def get(self, request):
        return render(request, self.template_name)

    def post(self, request):
        otp_submitted = request.POST.get('otp_code', None)
        if otp_submitted is not None:
             return self.verify_otp(request, otp_submitted)

        cipher_text = request.POST.get('cipher_text', '').strip()
        decryption_key = request.POST.get('decryption_key', '').strip()

        context = {'cipher_text_submitted': cipher_text}

        if not cipher_text:
            context['error'] = 'Cipher text is required for decryption.'
            return render(request, self.template_name, context)
            
        if not decryption_key:
            context['error'] = 'Decryption key is required.'
            return render(request, self.template_name, context)

        decrypted_val = cipher.decrypt_text(cipher_text, decryption_key)
        
        if decrypted_val is not None:
            import random
            from .models import OTPVerification
            otp_val = str(random.randint(100000, 999999))
            OTPVerification.objects.create(user=request.user, otp_code=otp_val)
            
            mobile = getattr(request.user, 'profile', None)
            mobile_str = mobile.mobile_number if mobile else "0000000000"
            masked_mobile = f"******{mobile_str[-4:]}" if len(mobile_str) >= 4 else "******0000"
            
            print(f">>>>> REAL TIME SMS OTP SENT TO {masked_mobile} (User: {request.user.username}): {otp_val} <<<<<")
            
            request.session['temp_decrypted_val'] = decrypted_val
            request.session['temp_cipher_text'] = cipher_text
            request.session['temp_masked_mobile'] = masked_mobile
            request.session['temp_otp_val'] = otp_val
            
            context['script_override'] = 'simulate_otp'
            context['masked_mobile'] = masked_mobile
            context['otp_debug'] = otp_val
        else:
            context['error'] = 'Invalid cipher or decryption key. Integrity check failed.'
            CryptoLog.objects.create(
                user=request.user,
                operation_type='DECRYPT',
                text_fragment=cipher_text[:30] + '...',
                full_cipher='FAILED',
                status='FAILED'
            )

        return render(request, self.template_name, context)

    def verify_otp(self, request, otp_submitted):
        from .models import OTPVerification
        masked_mobile = request.session.get('temp_masked_mobile', '******0000')
        otp_val = request.session.get('temp_otp_val', '')
        context = {
            'cipher_text_submitted': request.session.get('temp_cipher_text', ''),
            'script_override': 'simulate_otp',
            'masked_mobile': masked_mobile,
            'otp_debug': otp_val
        }
        try:
             otp_record = OTPVerification.objects.filter(user=request.user, is_used=False).latest('created_at')
             if otp_record.otp_code == otp_submitted:
                 otp_record.is_used = True
                 otp_record.save()
                 
                 decrypted_text = request.session.pop('temp_decrypted_val', '')
                 context['decrypted_text'] = decrypted_text
                 context['script_override'] = 'simulate_success'
                 
                 CryptoLog.objects.create(
                     user=request.user,
                     operation_type='DECRYPT',
                     text_fragment=context['cipher_text_submitted'][:30] + '...',
                     full_cipher=decrypted_text,
                     status='SUCCESS'
                 )
                 return render(request, self.template_name, context)
             else:
                 context['error'] = 'Invalid 6-digit OTP code.'
                 return render(request, self.template_name, context)
        except Exception as e:
             logger.error(f"OTP Verification Error: {e}")
             context['error'] = 'OTP verification sequence failed. Please restart decryption.'
             context['script_override'] = None
             return render(request, self.template_name, context)


class MessageHistoryView(LoginRequiredMixin, ListView):
    template_name = 'dashboard/message_history.html'
    context_object_name = 'logs'
    paginate_by = 10

    def get_queryset(self):
        return CryptoLog.objects.filter(user=self.request.user)

class PasswordGeneratorView(LoginRequiredMixin, TemplateView):
    template_name = 'dashboard/password_generator.html'

class ProfileView(LoginRequiredMixin, View):
    template_name = 'dashboard/profile.html'
    
    def get(self, request):
        return render(request, self.template_name)
        
    def post(self, request):
        first_name = request.POST.get('first_name', '')
        last_name = request.POST.get('last_name', '')
        email = request.POST.get('email', '')
        password = request.POST.get('password', '')
        
        if not request.user.check_password(password):
             messages.error(request, 'Invalid authorization password.')
             return render(request, self.template_name)
             
        request.user.first_name = first_name
        request.user.last_name = last_name
        request.user.email = email
        request.user.save()
        messages.success(request, 'Operator profile updated successfully.')
        return render(request, self.template_name)

class SecurityCenterView(LoginRequiredMixin, TemplateView):
    template_name = 'dashboard/security_center.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from .models import CryptoLog, UserDeviceSession
        logs = CryptoLog.objects.filter(user=self.request.user)
        total = logs.count()
        success = logs.filter(status='SUCCESS').count()
        context['security_score'] = int((success / total) * 100) if total > 0 else 100
        context['recent_threat'] = logs.filter(status='FAILED').first()
        
        context['sessions'] = UserDeviceSession.objects.filter(user=self.request.user)[:5]
        return context
